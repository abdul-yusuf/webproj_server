function myFunction() {
    var element = document.getElementById("hide-para");
    element.classList.toggle("hide-para");
  }